import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

def init_db():
    try:
        conn = psycopg2.connect(
            dbname="postgres",
            user="postgres",
            password="admin123",
            host="localhost",
            port=5432
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM pg_database WHERE datname='IMS'")
        exists = cur.fetchone()
        if not exists:
            cur.execute('CREATE DATABASE "IMS"')
            print("Created database 'IMS' successfully!")
        else:
            print("Database 'IMS' already exists.")
        cur.close()
        conn.close()
    except Exception as e:
        print("Database connection error:", e)

if __name__ == "__main__":
    init_db()
