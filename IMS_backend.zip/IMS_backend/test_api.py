import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_api_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "online"

def test_admin_login_and_me():
    # Login with seeded admin
    login_res = client.post("/api/v1/auth/login", data={"username": "admin@netsol.com", "password": "Admin@123"})
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    assert token is not None

    # Call /auth/me
    headers = {"Authorization": f"Bearer {token}"}
    me_res = client.get("/api/v1/auth/me", headers=headers)
    assert me_res.status_code == 200
    user_data = me_res.json()
    assert user_data["email"] == "admin@netsol.com"
    assert user_data["role"]["name"] == "admin"
    assert len(user_data["permissions"]) > 0
    assert "user:read" in user_data["permissions"]

def test_intern_registration_and_rbac():
    # Register new intern
    intern_email = "test_intern_01@netsol.com"
    reg_data = {
        "email": intern_email,
        "password": "Password@123",
        "full_name": "Test Intern One",
        "department": "Engineering",
        "university": "FAST NUCES",
        "degree": "BS Computer Science",
        "semester": "7th"
    }
    reg_res = client.post("/api/v1/auth/register", json=reg_data)
    assert reg_res.status_code in [201, 400]  # 400 if already created

    # Login as intern
    login_res = client.post("/api/v1/auth/login", data={"username": intern_email, "password": "Password@123"})
    assert login_res.status_code == 200
    intern_token = login_res.json()["access_token"]
    intern_headers = {"Authorization": f"Bearer {intern_token}"}

    # Verify intern permissions
    me_res = client.get("/api/v1/auth/me", headers=intern_headers)
    assert me_res.status_code == 200
    intern_data = me_res.json()
    assert intern_data["role"]["name"] == "intern"
    assert "report:create" in intern_data["permissions"]
    assert "user:delete" not in intern_data["permissions"]

    # Intern attempts admin endpoint (GET /users) -> Should be 403 Forbidden
    users_res = client.get("/api/v1/users", headers=intern_headers)
    assert users_res.status_code == 403

def test_ai_services_endpoints():
    # Login as admin to test AI
    login_res = client.post("/api/v1/auth/login", data={"username": "admin@netsol.com", "password": "Admin@123"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Test Chat Q&A
    chat_res = client.post("/api/v1/ai/chat", json={"query": "How many active interns are in the system?"}, headers=headers)
    assert chat_res.status_code == 200
    chat_data = chat_res.json()
    assert "response" in chat_data
    assert len(chat_data["response"]) > 0

if __name__ == "__main__":
    pytest.main(["-v", "test_api.py"])
